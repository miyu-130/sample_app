# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '48b35654741f6e77ad700edbb9ffb5e22c3ef715e48405bfffe5d4cd5b39889b8e5ea7097e3c71e293f7d62bfda18ddff4740084e8ca74f5b79759aac245a77d'